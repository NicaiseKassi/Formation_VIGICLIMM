k=0
while k inferieur 6 :
k+=2
print(k)
