## 2024.3.15

### Weather indicators

* [#1](https://gitlab.mfi.tls/science-dev/nwp-processing/vigiclimm-indicators/-/issues/1) Feature: Add etp indicator script
* [#3](https://gitlab.mfi.tls/science-dev/nwp-processing/vigiclimm-indicators/-/issues/3) Feature: Add degree days indicator script
* [#6](https://gitlab.mfi.tls/science-dev/nwp-processing/vigiclimm-indicators/-/issues/6) Feature: Add daily forecast script

### Extreme indicators

* [#2](https://gitlab.mfi.tls/science-dev/nwp-processing/vigiclimm-indicators/-/issues/2) Feature: Add extreme events scripts

### Miscellaneous

* [#13](https://gitlab.mfi.tls/science-dev/nwp-processing/vigiclimm-indicators/-/issues/13): Feature: Complete README.md
