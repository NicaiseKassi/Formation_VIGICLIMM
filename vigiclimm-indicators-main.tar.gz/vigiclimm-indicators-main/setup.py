# Minimal setup.py
import setuptools
setuptools.setup()
