.. vigiclimm_indicators documentation master file, created by
   sphinx-quickstart on Tue May 14 15:46:55 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to vigiclimm_indicators's documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

    modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
